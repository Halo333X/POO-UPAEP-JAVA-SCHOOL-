package house_utils.cocina;

public class Refrigerador {
    public void usar() {
        System.out.println("Usando el refrigerador.");
    }
}
