package house_utils.cocina;

public class Lavabo {
    public void usar() {
        System.out.println("Usando el lávabo.");
    }
}
