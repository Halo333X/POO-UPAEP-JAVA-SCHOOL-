package house_utils.cocina;

public class Microondas {
    public void usar() {
        System.out.println("Usando el microondas.");
    }
}
