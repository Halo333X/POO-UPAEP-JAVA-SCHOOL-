package house_utils.cocina;

public class Cubiertos {

    public void usar() {
        System.out.println("Usando los cubiertos.");
    }
}