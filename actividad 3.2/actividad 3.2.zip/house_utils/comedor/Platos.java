package house_utils.comedor;

public class Platos {
    public void usar(int length) {
        System.out.println("Usando los platos. (" + length + ")");
    }
}
