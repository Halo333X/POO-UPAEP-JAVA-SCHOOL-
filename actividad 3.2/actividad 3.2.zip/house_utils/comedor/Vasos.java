package house_utils.comedor;

public class Vasos {
    public void usar(int length) {
        System.out.println("Usando los vasos. (" + length + ")");
    }
}
