package house_utils.comedor;

public class Mesa {
    public void usar() {
        System.out.println("Usando la mesa.");
    }
}
