package house_utils.comedor;

public class Frutas {
    public void usar(int length) {
        System.out.println("Usando las frutas. (" + length + ")");
    }
}
