package house_utils.dormitorio;

public class Ropa {
    public void usar() {
        System.out.println("Usando la ropa.");
    }
}
