package house_utils.dormitorio;

public class Espejos {
    public void usar(int length) {
        System.out.println("Usando los espejos. (" + length + ")");
    }
}
