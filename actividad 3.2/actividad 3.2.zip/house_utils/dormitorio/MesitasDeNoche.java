package house_utils.dormitorio;

public class MesitasDeNoche {
    public void usar(int length) {
        System.out.println("Usando las mesitas de noche. (" + length + ")");
    }
}
