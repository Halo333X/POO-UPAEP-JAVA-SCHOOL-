package house_utils.dormitorio;

public class Lamparas {
    public void usar(int length) {
        System.out.println("Usando las lamparas. (" + length + ")");
    }
}
