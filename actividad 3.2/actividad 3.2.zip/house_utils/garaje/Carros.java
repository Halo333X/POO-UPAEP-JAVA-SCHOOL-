package house_utils.garaje;

public class Carros {
    public void usar(int length) {
        System.out.println("Usando los carros. (" + length + ")");
    }
}
