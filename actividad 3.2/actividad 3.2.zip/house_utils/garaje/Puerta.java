package house_utils.garaje;

public class Puerta {
    public void usar() {
        System.out.println("Usando la puerta.");
    }
}
