package house_utils.baño;

public class WC {
    public void usar() {
        System.out.println("Usando el WC.");
    }
}
