package house_utils.baño;

public class Espejo {
    public void usar() {
        System.out.println("Usando el espejo.");
    }
}
