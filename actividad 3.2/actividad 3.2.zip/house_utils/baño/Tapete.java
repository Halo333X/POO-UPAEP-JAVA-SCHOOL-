package house_utils.baño;

public class Tapete {
    public void usar() {
        System.out.println("Usando el tapete.");
    }
}
