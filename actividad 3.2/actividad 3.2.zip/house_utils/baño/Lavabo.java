package house_utils.baño;

public class Lavabo {
    public void usar() {
        System.out.println("Usando el lavabo.");
    }
}
