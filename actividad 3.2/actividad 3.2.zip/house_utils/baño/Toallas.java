package house_utils.baño;

public class Toallas {
    public void usar(int length) {
        System.out.println("Usando las toallas. (" + length + ")");
    }
}
