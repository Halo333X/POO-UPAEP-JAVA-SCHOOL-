package house_utils.baño;

public class Regadera {
    public void usar() {
        System.out.println("Usando la regadera.");
    }
}
