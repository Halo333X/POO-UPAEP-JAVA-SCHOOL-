package house_utils.sala;

public class Sillones {
    public void usar(int length) {
        System.out.println("Usando los sillones. (" + length + ")");
    }
}
