package house_utils.sala;

public class ControlTV {
    public void usar() {
        System.out.println("Usando el control de TV.");
    }
}
