package house_utils.dormitorio;

public class Camas {
    public void usar(int length) {
        System.out.println("Usando las camas. (" + length + ")");
    }
}
