package house_utils.dormitorio;

public class Closets {
    public void usar(int length) {
        System.out.println("Usando los closets. (" + length + ")");
    }
}
