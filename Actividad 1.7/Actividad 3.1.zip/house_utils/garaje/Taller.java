package house_utils.garaje;

public class Taller {
    public void usar() {
        System.out.println("Usando el taller.");
    }
}
