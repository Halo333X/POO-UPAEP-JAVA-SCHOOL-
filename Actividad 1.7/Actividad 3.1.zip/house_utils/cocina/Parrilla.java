package house_utils.cocina;

public class Parrilla {
    public void usar() {
        System.out.println("Usando la parrilla.");
    }
}