package house_utils.cocina;

public class Horno {
    public void usar() {
        System.out.println("Usando el horno.");
    }
}