package house_utils.sala;

public class TV {
    public void usar() {
        System.out.println("Usando la TV.");
    }
}
