package house_utils.sala;

public class MesaBaja {
    public void usar() {
        System.out.println("Usando la mesa baja.");
    }
}
